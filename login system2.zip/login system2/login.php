<?php

session_start();

 $msg = '';
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");

//if (isset($_POST['login_btn'])){
	if($_SERVER["REQUEST_METHOD"] == "POST") {
	
	$myusername = mysqli_real_escape_string($db,$_POST['username']);
	$mypassword = mysqli_real_escape_string($db,$_POST['password']);
	$passwordmd5 = md5($mypassword); // hashed 
	$sql = "SELECT * FROM studentlogin WHERE username= '$myusername' and password = '$mypassword'";
	$result = mysqli_query($db, $sql);
	$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
	
	if ($count == 1){
		//$_SESSION['message']= "You are now logged in";
		
		//$_SESSION['username']= $username;
		header ("location: home.php"); // redirect to home page
	}else {
			
				//$_SESSION['message']= "Username Password combination is Incorrect";	
				$error = 'Wrong username or password';
		}
	}


?>

<html>
<head>
<title> OFFICER CANDIDATE MANAGEMENT SYSTEM </title>
<link rel="stylesheet" type="text/css" href="style3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>
<div class ="header">
<h1> <em> <i>OFFICER CANDIDATE MANAGEMENT SYSTEM</em></i></h1>
</div>
<br>
<ul>
<em><i><a href = "#">Home</a></em></i>
<em><i><a href = "welcome.php">Register</a></em></i>
<em><i><a href = "#">About</a></em></i>
<em><i><a href = "#">Contacts</a></em></i>
<em><i><a href = "#">Carrers</a></em></i>
<em><i><a href = "#">Gallery</a></em></i>
<em><i><a href = "#">Services</a></em></i>
<em><i><a href = "#">Events</a></em></i>
<em><i><a href = "#">Investors</a></em></i>
</ul>
<br> 
<form method ="post" action ="">
<table border=0>
<tr>
<td>username:</td>
<td><input type="text" name= "username" class= "textInput" required></td>
</tr>
<tr> 
<td>password:</td>
<td><input type="password" name= "password" class= "textInput" required></td>
</tr>




<tr>

<td colspan=2> 
<br>
<div class="text-center">

<input type="submit" name="Login_btn" value="LOGIN"></td>
<label name="message"></label>
</div>
</tr>
</table>

</form>

</body>
</html>