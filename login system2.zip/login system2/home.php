<?php
session_start();

?>



<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style3.css">
</head>
<body>
<div id="bg">
<div class ="header">
<ul>
<em><i><a href = "#">Home</a></em></i>
<em><i><a href = "#">About</a></em></i>
<em><i><a href = "#">Contacts</a></em></i>
<em><i><a href = "#">Carrers</a></em></i>
</ul>

<div style="text-align:left;"> 
</div>
</div>
</div>

<div> <h4><center>!!!WELCOME USER!!!</center></h4></div>
<div style="text-align:center;"> 
<a href="logout.php">Logout</a>
</div>
</body>


</html>
