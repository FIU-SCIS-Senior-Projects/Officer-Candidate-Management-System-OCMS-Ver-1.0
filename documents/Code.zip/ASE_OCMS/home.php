<?php
session_start();

?>



<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>Welcome Home!<br> <?=$_SESSION['username'];?></br></center></em></i>
 <br>
</div>
<div class="container" style="height:0px;">
<div class="container">
<div class="row">
<br>
<div class="row" style="text-align:right; color:white;"> 
<a href="logout.php" style=" color:white" class="btn btn-primary">Logout</a>
</div>

<div class="dropdown">
 <div style="text-align:left;">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">ViewProfile
  <span class="caret"></span></button>
  <ul class="dropdown-menu col-sm-2">
    <li><a href="profileme.php">Display</a></li>
     </ul>
</div>
</div>
<br>

 <div class="dropdown">
 <div style="text-align:left;">
  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">MarkAttendance
  <span class="caret"></span></button>
  <ul class="dropdown-menu col-sm-2">
    
    <li><a href="attendance.php">ClickHere</a></li>
	
	
   
  </ul>
  
</div>
</div>

<div style="text-align:left;"> </div>
</div>
<br>
</div>
</div>
</div>
</body>


</html>
