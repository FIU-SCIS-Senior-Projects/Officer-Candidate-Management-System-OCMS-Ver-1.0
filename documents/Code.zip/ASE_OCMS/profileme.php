<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style1.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>SEE YOUR PROFILE</center></em></i>
<br>
</div>
<br>

<div style="text-align:left;"> </div>

<div class="container">
<div class="container" style="height:0px;">
<p>
       
      </p>
	  


</div>
</div>
</body>


</html>

<?php
   // connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $query = "SELECT username, email, phonenumber, school, rank, academicyear,Role FROM studentlogin where username = '" . $_SESSION['username'] . "'";
	
      if($result = $db->query($query))
{
    while($row = $result->fetch_assoc())
    { 
echo '<div class="container">';
        
        echo '<div class="row col-sm-4">';
        echo "<b>Name:</b> ". $row['username'];
        echo "<br /><b>Email:</b> ".$row['email'];
        echo "<br /><b>Phone Number:</b> ".$row['phonenumber'];
        echo "<br /><b>School:</b> ".$row['school'];
        echo "<br /><b>Rank:</b> ".$row['rank'];
		echo "<br /><b>Academic Year:</b>".$row['academicyear'];
		echo "<br /><b>Role:</b>".$row['Role'];
echo '</div>';
		
        echo "</div>";   
    }
}
   


    
    ?>
	
	