<?php

session_start();

 $error = '';
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

//if (isset($_POST['login_btn'])){
	if (isset($_POST['username'])){
			$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($db,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($db,$password);
	 $query = "SELECT * FROM `studentlogin` WHERE username='$username' and password='".md5($password)."'";
	 $result = mysqli_query($db,$query) or die(mysql_error());
	 
	 $rows = mysqli_num_rows($result);
	  if($rows==1){
		  $_SESSION['username'] = $username;
		     header("Location: home.php");
         }else{
			$error = 'Wrong username or password';
			 	
	
		 }}
	
	
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> OFFICER CANDIDATE MANAGEMENT SYSTEM </title>

<link rel="stylesheet" type="text/css" href="style3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<div class ="header">
<h1> <em> <i>OFFICER CANDIDATE MANAGEMENT SYSTEM</em></i></h1>
</div>

<body>
<div class="container" style="height:0px;">
<div class="row">
  <div id="nav">
  <ul class="nav nav-pills ">
    <li class="active"><a href="welcome.php">Register</a></li>
	<li class="active"><a href="supervisorlogin.php">SupervisorLogin</a></li>
	<li class="active"><a href="studentlogin.php">StudentLogin</a></li>
	<li class="active"><a href="#">Gallery</a></li>
	<li class="active"><a href="#">About</a></li>
	<li class="active"><a href="#">Contacts</a></li>
	<li class="active"><a href="#">Carrers</a></li>
	<li class="active"><a href="#">Services</a></li>
	
    
   
  </ul>
  </div>
  </div>
</div>


 
	
	


</div>
</body>
</html>