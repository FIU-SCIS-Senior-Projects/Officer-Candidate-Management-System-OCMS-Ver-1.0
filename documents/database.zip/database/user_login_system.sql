-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2016 at 09:16 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_login_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `sign` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `ID` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`sign`, `datetime`, `ID`) VALUES
('hanss', '2016-11-20 00:48:34', 5),
('hseth', '2016-11-20 00:59:23', 6),
('hanssa', '2016-11-20 01:08:26', 7),
('rebecca', '2016-11-20 01:34:51', 8),
('rebecca', '2016-11-20 14:08:41', 9),
('ishan', '2016-11-20 14:38:59', 10),
('hansini', '2016-11-20 15:49:22', 11),
('hansini', '2016-11-20 15:52:20', 12),
('hans', '2016-11-20 17:13:44', 13),
('hansini seth', '2016-11-20 19:32:48', 14),
('hansini', '2016-11-20 23:05:20', 15),
('ishan shrivastava', '2016-11-20 23:30:33', 16);

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` int(100) NOT NULL,
  `school` enum('Florida International University','Barry University','Broward College','Miami Dade College','University of Miami','Florida Memorial University','FLorida Atlantic University') NOT NULL,
  `rank` enum('CADRE','CADET') NOT NULL,
  `academicyear` int(100) NOT NULL,
  `Role` enum('Student','Supervisor') NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmpassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`username`, `email`, `phonenumber`, `school`, `rank`, `academicyear`, `Role`, `password`, `confirmpassword`) VALUES
('ajay', 'ajay@gmail.com', 2147483647, 'Broward College', '', 2, 'Supervisor', '6ca29d9bb530402bd09fe026ee838148', 'poiu'),
('Barber', 'b@hotmail.com', 1112221112, 'FLorida Atlantic University', 'CADET', 3, 'Supervisor', '3bad6af0fa4b8b330d162e19938ee981', 'qqqq'),
('hansini', 'hansini.sims@gmail.com', 2147483647, 'Broward College', 'CADET', 1, 'Student', '827ccb0eea8a706c4c34a16891f84e7b', '12345'),
('ishan', 'ishan2266@gmail.com', 2147483647, 'University of Miami', 'CADET', 2, 'Supervisor', '962012d09b8170d912f0669f6d7d9d07', 'qwer'),
('maria', 'ma@hotmail.com', 2147483647, 'Broward College', 'CADET', 2, 'Supervisor', '962012d09b8170d912f0669f6d7d9d07', 'qwer'),
('rebecca', 're@gmail.com', 2147483647, 'Florida Memorial University', 'CADET', 2, 'Supervisor', '4eae18cf9e54a0f62b44176d074cbe2f', 'qaz');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `studentlogin`
--
ALTER TABLE `studentlogin`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
